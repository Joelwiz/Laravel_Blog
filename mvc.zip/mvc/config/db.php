<?php
#config/db.php
#https://bitbucket.org/rafacabeza/mvc18/src/mvc07/config/db.php

namespace Config;

const DSN = 'mysql:dbname=mvc;host=localhost;port=4633;charset=utf8';
const USER = 'root';
const PASSWORD = '';