<?php

require 'vendor/autoload.php';

$app = new \Core\App();
//use App\Models\Type;
//var_dump( Type::all() );
